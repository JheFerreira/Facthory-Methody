/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factorymethody2;

/**
 *
 * @author JéssicaFerreira
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        FabricaKappa fabricaKappa = new FabricaKappa();
        Camisa camisateste1 = fabricaKappa.criarCCamisa();
        camisateste1.exibirInfo();
        
        FabricaAdidas fabricaAdidas = new FabricaAdidas();
        Camisa camisateste2 = fabricaAdidas.criarCCamisa();
        camisateste2.exibirInfo();
        
        FabricaPuma fabricaPuma = new FabricaPuma();
        Camisa camisateste3 = fabricaPuma.criarCCamisa();
        camisateste3.exibirInfo();
        
        
        FabricaUmbro fabricaUmbro = new FabricaUmbro();
        Camisa camisateste4 = fabricaUmbro.criarCCamisa();
        camisateste4.exibirInfo();
        
       FabricaNike fabricaNike = new FabricaNike();
       Camisa camisateste5 = fabricaNike.criarCCamisa();
       camisateste5.exibirInfo();
        
    }
    
}
